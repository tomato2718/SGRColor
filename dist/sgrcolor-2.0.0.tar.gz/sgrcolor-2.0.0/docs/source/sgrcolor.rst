sgrcolor package
================

Module contents
---------------

.. automodule:: sgrcolor
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __call__

Submodules
----------

sgrcolor.types module
^^^^^^^^^^^^^^^^^^^^^

.. automodule:: sgrcolor.types
   :members:
   :undoc-members:
   :show-inheritance:

   .. autodata:: FontStyles
   .. autodata:: Colors