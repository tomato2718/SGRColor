.. template documentation master file, created by
   sphinx-quickstart on Sun Jul  9 16:38:41 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to template's documentation!
====================================

Contents
------------------------------------

.. toctree::
   :maxdepth: 2
   :caption: Contents: