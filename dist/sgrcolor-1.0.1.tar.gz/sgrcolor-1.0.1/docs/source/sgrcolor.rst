sgrcolor package
================

Module contents
---------------

.. automodule:: sgrcolor
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __call__
